quiz = {
    1 : {
        "Question" : "What is the first name of Iron Man?",
        "Answer" : "Tony"
    },
    2 : {
        "Question" : "Who is called the god of lightning in Avengers?",
        "Answer" : "Thor"
    },
    3 : {
        "Question" : "Who carries a shield of American flag theme in Avengers?",
        "Answer" : "Captain America"
    },
    4 : {
        "Question" : "Which avenger is green in color?",
        "Answer" : "Hulk"
    },
    5 : {
        "Question" : "Which avenger can change it's size?",
        "Answer" : "AntMan"
    }
}